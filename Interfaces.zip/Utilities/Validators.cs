﻿using System;
using System.Text.RegularExpressions;

namespace EmployeeTimeTracker.Utilities
{
    /// <summary>
    /// Centralized validation helpers used across the entire application.
    /// Provides safe input parsing for employees, time records and menus.
    /// </summary>
    public static class Validators
    {
        // =======================================
        // EXISTING VALIDATORS (UNCHANGED)
        // =======================================

        public static int GetValidInt(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? input = Console.ReadLine();

                if (int.TryParse(input, out int value))
                    return value;

                Console.WriteLine("❌ Invalid number. Try again.");
            }
        }

        public static double GetValidDouble(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? input = Console.ReadLine();

                if (double.TryParse(input, out double value))
                    return value;

                Console.WriteLine("❌ Invalid numeric value. Try again.");
            }
        }

        public static string GetRequiredString(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? input = Console.ReadLine();

                if (!string.IsNullOrWhiteSpace(input))
                    return input.Trim();

                Console.WriteLine("❌ Input cannot be empty. Try again.");
            }
        }

        public static DateTime GetValidDateTime(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? input = Console.ReadLine();

                if (DateTime.TryParse(input, out DateTime value))
                    return value;

                Console.WriteLine("❌ Invalid date/time format. Example: 2025-11-20 08:30 AM");
            }
        }

        public static bool Confirm(string message)
        {
            while (true)
            {
                Console.Write($"{message} (y/n): ");
                string? input = Console.ReadLine()?.Trim().ToLower();

                if (input == "y") return true;
                if (input == "n") return false;

                Console.WriteLine("❌ Please type 'y' or 'n'.");
            }
        }

        // =======================================
        // NEW — EMAIL / ID / NUMERIC VALIDATION
        // =======================================

        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, pattern, RegexOptions.IgnoreCase);
        }

        public static bool IsValidId(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return false;

            string pattern = @"^[A-Za-z0-9]+$";
            return Regex.IsMatch(id, pattern);
        }

        public static bool IsPositiveNumber(decimal number)
        {
            return number > 0;
        }

        public static bool IsValidHours(decimal hours)
        {
            return hours >= 0 && hours <= 24;
        }

        // =======================================
        // NEW — REQUIRED BY EmployeeManager & Program
        // =======================================

        /// <summary>
        /// Allows a decimal input and retries until valid.
        /// </summary>
        public static decimal GetDecimal(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? input = Console.ReadLine();

                if (decimal.TryParse(input, out decimal value))
                    return value;

                Console.WriteLine("❌ Invalid decimal number. Try again.");
            }
        }

        /// <summary>
        /// Same as GetDecimal but also enforces positive values.
        /// </summary>
        public static decimal GetRequiredDecimal(string message)
        {
            while (true)
            {
                decimal value = GetDecimal(message);

                if (value > 0)
                    return value;

                Console.WriteLine("❌ Value must be positive.");
            }
        }

        /// <summary>
        /// Returns validated DateTime with retry.
        /// </summary>
        public static DateTime GetDate(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? input = Console.ReadLine();

                if (DateTime.TryParse(input, out DateTime value))
                    return value;

                Console.WriteLine("❌ Invalid date. Example: 2025-11-20");
            }
        }

        /// <summary>
        /// Same as GetDate but prevents empty or invalid values.
        /// </summary>
        public static DateTime GetRequiredDate(string message)
        {
            return GetDate(message);
        }

        /// <summary>
        /// Email validator that forces user to re-enter until valid format.
        /// Used by Program.cs and EmployeeManager.Validation.cs
        /// </summary>
        public static string GetValidatedEmail(string message)
        {
            while (true)
            {
                Console.Write(message);
                string? email = Console.ReadLine()?.Trim();

                if (!string.IsNullOrWhiteSpace(email) && IsValidEmail(email))
                    return email;

                Console.WriteLine("❌ Invalid email format. Try again.");
            }
        }

        /// <summary>
        /// Allows empty or null values (for notes, optional inputs).
        /// </summary>
        public static string GetOptionalString(string message)
        {
            Console.Write(message);
            string? input = Console.ReadLine();

            return input?.Trim() ?? string.Empty;
        }
    }
}
