using System;
using System.Collections.Generic;
using System.IO;

namespace EmployeeTimeTracker.Utilities
{
    /// <summary>
    /// Provides safe and simplified file I/O operations 
    /// for saving and loading data in text-based format.
    /// </summary>
    public static class FileHandler
    {
        /// <summary>
        /// Reads all lines from a file. 
        /// Returns an empty list if the file doesn�t exist.
        /// </summary>
        public static List<string> ReadAll(string path)
        {
            try
            {
                if (!File.Exists(path))
                    return new List<string>();

                return new List<string>(File.ReadAllLines(path));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[FileHandler] Error reading file '{path}': {ex.Message}");
                return new List<string>();
            }
        }

        /// <summary>
        /// Writes all lines to a file, replacing existing content.
        /// Auto-creates directories if needed.
        /// </summary>
        public static void WriteAll(string path, List<string> lines)
        {
            try
            {
                EnsureDirectoryExists(path);
                File.WriteAllLines(path, lines);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[FileHandler] Error writing file '{path}': {ex.Message}");
            }
        }

        /// <summary>
        /// Appends a single line to a file.
        /// Auto-creates directories if needed.
        /// </summary>
        public static void AppendLine(string path, string line)
        {
            try
            {
                EnsureDirectoryExists(path);
                File.AppendAllText(path, line + Environment.NewLine);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[FileHandler] Error appending to file '{path}': {ex.Message}");
            }
        }

        /// <summary>
        /// Ensures the directory for the file exists.
        /// </summary>
        private static void EnsureDirectoryExists(string path)
        {
            var folder = Path.GetDirectoryName(path);
            if (!string.IsNullOrWhiteSpace(folder) && !Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
        }
    }
}
