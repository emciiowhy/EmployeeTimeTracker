﻿//Program.cs
using System;
using System.Linq;
using EmployeeTimeTracker.Models;
using EmployeeTimeTracker.Managers;
using EmployeeTimeTracker.Utilities;
using EmployeeTimeTracker.MenuHandlers;

namespace EmployeeTimeTracker
{
    class Program
    {
        // FIXED → Non-nullable fields must be initialized.
        static EmployeeManager empManager = new EmployeeManager();
        static EmployeeMenu employeeMenu;
        static TimeRecordManager timeManager = new TimeRecordManager();

        static void Main(string[] args)
        {
            Initialize();
            MainMenu();
        }

        static void Initialize()
        {
            // Subscribing to EVENTS
            empManager.OnEmployeeChanged += (message) =>
            {
                Console.WriteLine($"[NOTIFICATION] {message}");
            };

            timeManager.OnClockEvent += (empId, time, action) =>
            {
                Console.WriteLine($"[CLOCK EVENT] {empId} - {action} at {time:HH:mm:ss}");
            };

            Console.WriteLine("Loading saved data...");
            empManager.LoadFromFile();
            timeManager.LoadFromFile();

            // initialize menu handlers
            employeeMenu = new EmployeeMenu(empManager);
        }

        // -------------------------------------------------------------
        // MAIN MENU
        // -------------------------------------------------------------
        static void MainMenu()
        {
            while (true)
            {
                Console.WriteLine("\n╔════════════════════════════════════════╗");
                Console.WriteLine("║   EMPLOYEE TIME TRACKER SYSTEM         ║");
                Console.WriteLine("╚════════════════════════════════════════╝");
                Console.WriteLine("[1] Employee Management");
                Console.WriteLine("[2] Time Tracking");
                Console.WriteLine("[3] Reports");
                Console.WriteLine("[4] Save & Exit");
                Console.Write("\nSelect option: ");

                string? choice = Console.ReadLine();

                try
                {
                    switch (choice)
                    {
                        case "1": EmployeeMenu(); break;
                        case "2": TimeTrackingMenu(); break;
                        case "3": ReportsMenu(); break;
                        case "4": SaveAndExit(); return;
                        default: Console.WriteLine("Invalid option."); break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"\n[ERROR] {ex.Message}");
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
        }

        // -------------------------------------------------------------
        // EMPLOYEE MENU
        // -------------------------------------------------------------
        static void EmployeeMenu()
        {
            while (true)
            {
                Console.WriteLine("\n--- EMPLOYEE MANAGEMENT ---");
                Console.WriteLine("[1] Add Full-Time Employee");
                Console.WriteLine("[2] Add Part-Time Employee");
                Console.WriteLine("[3] Remove Employee");
                Console.WriteLine("[4] View All Employees");
                Console.WriteLine("[5] Find Employee");
                Console.WriteLine("[6] Search Employee by Name");
                Console.WriteLine("[0] Back to Main Menu");
                Console.Write("\nSelect: ");

                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1": AddFullTimeEmployee(); break;
                    case "2": AddPartTimeEmployee(); break;
                    case "3": RemoveEmployee(); break;
                    case "4": empManager.DisplayAllEmployees(); break;
                    case "5": FindEmployee(); break;
                    case "6": employeeMenu.ShowEmployeeSearchMenu(); break;
                    case "0": return;
                    default: Console.WriteLine("Invalid option."); break;
                }
            }
        }

        // -------------------------------------------------------------
        // ADD EMPLOYEE (Full-Time)
        // -------------------------------------------------------------
        static void AddFullTimeEmployee()
        {
            try
            {
                string id = Validators.GetRequiredString("Employee ID: ");

                // UNIQUE ID
                if (empManager.IdExists(id))
                {
                    Console.WriteLine("Error: ID already exists.");
                    return;
                }

                string name = Validators.GetRequiredString("Name: ");
                string email = Validators.GetValidatedEmail("Email: ");

                // UNIQUE EMAIL
                if (empManager.EmailExists(email))
                {
                    Console.WriteLine("Error: Email already exists.");
                    return;
                }

                decimal salary = Validators.GetDecimal("Monthly Salary: ");
                decimal overtimeRate = Validators.GetDecimal("Overtime Rate (per hour): ");

                var employee = new FullTimeEmployee(id, name, email, DateTime.Now, salary, overtimeRate);
                empManager.AddEmployee(employee);

                Console.WriteLine("Full-time employee added successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        // -------------------------------------------------------------
        // ADD EMPLOYEE (Part-Time)
        // -------------------------------------------------------------
        static void AddPartTimeEmployee()
        {
            try
            {
                string id = Validators.GetRequiredString("Employee ID: ");

                if (empManager.IdExists(id))
                {
                    Console.WriteLine("Error: ID already exists.");
                    return;
                }

                string name = Validators.GetRequiredString("Name: ");
                string email = Validators.GetValidatedEmail("Email: ");

                if (empManager.EmailExists(email))
                {
                    Console.WriteLine("Error: Email already exists.");
                    return;
                }

                decimal hourlyRate = Validators.GetDecimal("Hourly Rate: ");

                var employee = new PartTimeEmployee(id, name, email, DateTime.Now, hourlyRate);
                empManager.AddEmployee(employee);

                Console.WriteLine("Part-time employee added successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        // -------------------------------------------------------------
        // DELETE EMPLOYEE (with confirmation)
        // -------------------------------------------------------------
        static void RemoveEmployee()
        {
            string id = Validators.GetRequiredString("Enter Employee ID to remove: ");

            var employee = empManager.FindEmployeeById(id);
            if (employee == null)
            {
                Console.WriteLine("Employee not found.");
                return;
            }

            Console.WriteLine($"\nAre you sure you want to delete:");
            Console.WriteLine($"{employee.EmployeeId} - {employee.Name}");
            if (!Validators.Confirm("Confirm delete? (y/n): "))
            {
                Console.WriteLine("Cancelled.");
                return;
            }

            if (empManager.RemoveEmployee(id))
                Console.WriteLine("Employee removed successfully.");
        }

        // -------------------------------------------------------------
        static void FindEmployee()
        {
            string id = Validators.GetRequiredString("Enter Employee ID: ");
            var employee = empManager.FindEmployeeById(id);

            if (employee != null)
            {
                Console.WriteLine("\n--- EMPLOYEE DETAILS ---");
                employee.DisplayInfo();
            }
            else
            {
                Console.WriteLine("Employee not found.");
            }
        }

        // -------------------------------------------------------------
        // TIME TRACKING MENU
        // -------------------------------------------------------------
        static void TimeTrackingMenu()
        {
            while (true)
            {
                Console.WriteLine("\n--- TIME TRACKING ---");
                Console.WriteLine("[1] Clock In");
                Console.WriteLine("[2] Clock Out");
                Console.WriteLine("[3] View Employee Time Records");
                Console.WriteLine("[0] Back");
                Console.Write("\nSelect: ");

                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1": ClockIn(); break;
                    case "2": ClockOut(); break;
                    case "3": ViewTimeRecords(); break;
                    case "0": return;
                    default: Console.WriteLine("Invalid option."); break;
                }
            }
        }

        static void ClockIn()
        {
            string id = Validators.GetRequiredString("Employee ID: ");
            var employee = empManager.FindEmployeeById(id);

            if (employee == null)
            {
                Console.WriteLine("Employee not found.");
                return;
            }

            Console.Write("Notes (optional): ");
            string? notes = Console.ReadLine();

            // FIXED → avoid passing null
            notes ??= "";

            timeManager.ClockIn(id, notes);
        }

        static void ClockOut()
        {
            string id = Validators.GetRequiredString("Employee ID: ");
            timeManager.ClockOut(id);
        }

        static void ViewTimeRecords()
        {
            string id = Validators.GetRequiredString("Employee ID: ");
            timeManager.DisplayEmployeeRecords(id);
        }

        // -------------------------------------------------------------
        // REPORTS
        // -------------------------------------------------------------
        static void ReportsMenu()
        {
            while (true)
            {
                Console.WriteLine("\n--- REPORTS ---");
                Console.WriteLine("[1] Employee Summary Report");
                Console.WriteLine("[2] Calculate Pay for Employee");
                Console.WriteLine("[3] Monthly Hours Report");
                Console.WriteLine("[0] Back");
                Console.Write("\nSelect: ");

                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1": empManager.GenerateSummaryReport(); break;
                    case "2": CalculateEmployeePay(); break;
                    case "3": MonthlyHoursReport(); break;
                    case "0": return;
                    default: Console.WriteLine("Invalid option."); break;
                }
            }
        }

        static void CalculateEmployeePay()
        {
            string id = Validators.GetRequiredString("Employee ID: ");
            var employee = empManager.FindEmployeeById(id);

            if (employee == null)
            {
                Console.WriteLine("Employee not found.");
                return;
            }

            DateTime startDate = Validators.GetDate("Enter start date (yyyy-MM-dd): ");
            DateTime endDate = Validators.GetDate("Enter end date (yyyy-MM-dd): ");

            double totalHours = timeManager.CalculateTotalHours(id, startDate, endDate);
            decimal pay = employee.CalculatePay(totalHours);

            Console.WriteLine("\n--- PAY CALCULATION ---");
            Console.WriteLine($"Employee: {employee.Name}");
            Console.WriteLine($"Period: {startDate:yyyy-MM-dd} to {endDate:yyyy-MM-dd}");
            Console.WriteLine($"Total Hours: {totalHours:F2}");
            Console.WriteLine($"Total Pay: {pay:C}");
        }

        static void MonthlyHoursReport()
        {
            Console.WriteLine("\n--- MONTHLY HOURS REPORT ---");

            var allEmployees = empManager.GetAllEmployees();
            if (allEmployees.Count == 0)
            {
                Console.WriteLine("No employees found.");
                return;
            }

            DateTime startOfMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            DateTime endOfMonth = startOfMonth.AddMonths(1).AddDays(-1);

            Console.WriteLine($"Period: {startOfMonth:yyyy-MM-dd} to {endOfMonth:yyyy-MM-dd}\n");

            allEmployees.OrderBy(e => e.Name).ToList().ForEach(emp =>
            {
                double hours = timeManager.CalculateTotalHours(emp.EmployeeId, startOfMonth, endOfMonth);
                Console.WriteLine($"{emp.EmployeeId} - {emp.Name}: {hours:F2} hours");
            });
        }

        // -------------------------------------------------------------
        static void SaveAndExit()
        {
            Console.WriteLine("\nSaving data...");
            empManager.SaveToFile();
            timeManager.SaveToFile();
            Console.WriteLine("Data saved. Goodbye!");
        }
    }
}