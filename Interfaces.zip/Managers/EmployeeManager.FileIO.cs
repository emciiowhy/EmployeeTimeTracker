﻿using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Collections.Generic;
using EmployeeTimeTracker.Models;

namespace EmployeeTimeTracker.Managers
{
    // Partial: File I/O (JSON-only)
    public partial class EmployeeManager
    {
        private const string FILE_PATH = "employees.json";

        public void SaveToFile()
        {
            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Converters = { new PolymorphicEmployeeConverter() }
                };

                string json = JsonSerializer.Serialize(employees, options);
                File.WriteAllText(FILE_PATH, json);
                Console.WriteLine("Employees saved to employees.json");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving employees: {ex.Message}");
            }
        }

        public void LoadFromFile()
        {
            try
            {
                if (!File.Exists(FILE_PATH))
                {
                    Console.WriteLine("No saved employee data found.");
                    return;
                }

                string json = File.ReadAllText(FILE_PATH);

                var options = new JsonSerializerOptions
                {
                    Converters = { new PolymorphicEmployeeConverter() }
                };

                var list = JsonSerializer.Deserialize<List<Employee>>(json, options);
                if (list != null)
                {
                    employees.Clear();
                    employees.AddRange(list);
                }

                Console.WriteLine($"Loaded {employees.Count} employees from file.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading employees: {ex.Message}");
            }
        }
    }

    // JSON converter to handle FullTimeEmployee / PartTimeEmployee polymorphism
    public class PolymorphicEmployeeConverter : JsonConverter<Employee>
    {
        public override Employee? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            using var doc = JsonDocument.ParseValue(ref reader);
            var root = doc.RootElement;

            if (!root.TryGetProperty("Type", out var tProp))
            {
                // fallback: try to detect by presence of fields
                if (root.TryGetProperty("MonthlySalary", out _))
                {
                    return JsonSerializer.Deserialize<FullTimeEmployee>(root.GetRawText(), options);
                }
                if (root.TryGetProperty("HourlyRate", out _))
                {
                    return JsonSerializer.Deserialize<PartTimeEmployee>(root.GetRawText(), options);
                }
                return null;
            }

            string? type = tProp.GetString();
            return type switch
            {
                "FullTime" => JsonSerializer.Deserialize<FullTimeEmployee>(root.GetRawText(), options),
                "PartTime" => JsonSerializer.Deserialize<PartTimeEmployee>(root.GetRawText(), options),
                _ => null
            };
        }

        public override void Write(Utf8JsonWriter writer, Employee value, JsonSerializerOptions options)
        {
            var type = value switch
            {
                FullTimeEmployee _ => "FullTime",
                PartTimeEmployee _ => "PartTime",
                _ => "Employee"
            };

            using var jsonDoc = JsonDocument.Parse(JsonSerializer.Serialize(value, value.GetType(), options));
            writer.WriteStartObject();

            // write Type marker
            writer.WriteString("Type", type);

            // copy other properties from serialized object
            foreach (var prop in jsonDoc.RootElement.EnumerateObject())
            {
                prop.WriteTo(writer);
            }

            writer.WriteEndObject();
        }
    }
}
