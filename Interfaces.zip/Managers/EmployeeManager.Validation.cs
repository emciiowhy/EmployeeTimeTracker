﻿using System;
using System.Linq;
using EmployeeTimeTracker.Models;

namespace EmployeeTimeTracker.Managers
{
    // Partial: validation helpers (keeps validations grouped)
    public partial class EmployeeManager
    {
        /// <summary>
        /// Returns true if an employee ID already exists (case-insensitive).
        /// </summary>
        public bool IdExists(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return false;
            return employees.Any(e => e.EmployeeId.Equals(id, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Returns true if an email is already in use (case-insensitive).
        /// </summary>
        public bool EmailExists(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            return employees.Any(e => e.Email.Equals(email, StringComparison.OrdinalIgnoreCase));
        }
    }
}
