﻿//EmployeeManager.Core.cs
using System;
using System.Collections.Generic;
using System.Linq;
using EmployeeTimeTracker.Models;
using EmployeeTimeTracker.Utilities;

namespace EmployeeTimeTracker.Managers
{
    /// <summary>
    /// Core behavior for EmployeeManager: add/remove/find/get/report.
    /// This file is intentionally minimal — validation + file I/O are in other partial files.
    /// </summary>
    public partial class EmployeeManager
    {
        // single shared collection (initialized)
        private readonly List<Employee> employees = new List<Employee>();

        // event: subscribers can be null, so declare nullable
        public event Action<string>? OnEmployeeChanged;

        // Add employee (defensive: validates uniqueness & email)
        public void AddEmployee(Employee employee)
        {
            if (employee == null)
                throw new ArgumentNullException(nameof(employee));

            // basic validation
            if (string.IsNullOrWhiteSpace(employee.EmployeeId))
                throw new ArgumentException("Employee ID cannot be empty.");

            if (!Validators.IsValidEmail(employee.Email))
                throw new ArgumentException("Invalid email format.");

            // uniqueness checks (use methods defined in Validation partial)
            if (IdExists(employee.EmployeeId))
                throw new InvalidOperationException($"Employee ID '{employee.EmployeeId}' already exists.");

            if (EmailExists(employee.Email))
                throw new InvalidOperationException($"Email '{employee.Email}' is already used by another employee.");

            employees.Add(employee);

            // raise event safely
            OnEmployeeChanged?.Invoke($"Employee {employee.Name} ({employee.EmployeeId}) added.");
        }

        // Remove employee
        public bool RemoveEmployee(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                return false;

            var emp = FindEmployeeById(id);
            if (emp == null) return false;

            employees.Remove(emp);
            OnEmployeeChanged?.Invoke($"Employee {emp.Name} ({emp.EmployeeId}) removed.");
            return true;
        }

        // Find by id
        public Employee? FindEmployeeById(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return null;
            return employees.FirstOrDefault(e => e.EmployeeId.Equals(id, StringComparison.OrdinalIgnoreCase));
        }

        // Get copy of all employees (defensive copy)
        public List<Employee> GetAllEmployees()
        {
            return employees.ToList();
        }

        // Display summary / all employees
        public void DisplayAllEmployees()
        {
            if (employees.Count == 0)
            {
                Console.WriteLine("No employees found.");
                return;
            }

            Console.WriteLine("\n=== ALL EMPLOYEES ===");
            foreach (var emp in employees.OrderBy(e => e.Name))
            {
                emp.DisplayInfo();
                Console.WriteLine("---");
            }
        }

        public void GenerateSummaryReport()
        {
            Console.WriteLine("\n=== EMPLOYEE SUMMARY REPORT ===");
            Console.WriteLine($"Total Employees: {employees.Count}");
            Console.WriteLine($"Full-Time: {employees.Count(e => e is FullTimeEmployee)}");
            Console.WriteLine($"Part-Time: {employees.Count(e => e is PartTimeEmployee)}");

            if (employees.Count > 0)
            {
                var avgYears = employees.Average(e => (DateTime.Now - e.HireDate).TotalDays / 365);
                Console.WriteLine($"Average Tenure: {avgYears:F1} years");
            }
        }
        // 🔍 Search by name (full or partial, case-insensitive)
        public List<Employee> SearchEmployeesByName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return new List<Employee>();

            return employees
                .Where(e => e.Name.Contains(name, StringComparison.OrdinalIgnoreCase))
                .OrderBy(e => e.Name)
                .ToList();
        }

    }
}
