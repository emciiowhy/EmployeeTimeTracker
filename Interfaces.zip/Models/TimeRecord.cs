//TimeRecord.cs
using System;

namespace EmployeeTimeTracker.Models
{
    // Represents a single time record entry
    public class TimeRecord
    {
        public string RecordId { get; set; }
        public string EmployeeId { get; set; }
        public DateTime ClockIn { get; set; }
        public DateTime? ClockOut { get; set; } // Nullable - may not have clocked out yet
        public string Notes { get; set; }

        // Calculated property
        public double HoursWorked
        {
            get
            {
                if (ClockOut.HasValue)
                {
                    TimeSpan duration = ClockOut.Value - ClockIn;
                    return duration.TotalHours;
                }
                return 0; // Still clocked in
            }
        }

        public bool IsActive => !ClockOut.HasValue;

        // Constructor
        public TimeRecord(string recordId, string employeeId, DateTime clockIn, string notes = "")
        {
            RecordId = recordId;
            EmployeeId = employeeId;
            ClockIn = clockIn;
            ClockOut = null;
            Notes = notes;
        }

        // Method to clock out
        public void ClockOutNow()
        {
            if (ClockOut.HasValue)
                throw new InvalidOperationException("Already clocked out.");
            ClockOut = DateTime.Now;
        }

        // Display method
        public void DisplayRecord()
        {
            Console.WriteLine($"Record ID: {RecordId}");
            Console.WriteLine($"Clock In: {ClockIn}");
            Console.WriteLine($"Clock Out: {(ClockOut.HasValue ? ClockOut.Value.ToString() : "Still working")}");
            Console.WriteLine($"Hours: {HoursWorked:F2}");
            if (!string.IsNullOrEmpty(Notes))
                Console.WriteLine($"Notes: {Notes}");
        }
    }
}