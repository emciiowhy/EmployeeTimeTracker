//PartTimeEmployee.cs
using System;

namespace EmployeeTimeTracker.Models
{
    // Another child class demonstrating INHERITANCE and POLYMORPHISM
    public class PartTimeEmployee : Employee
    {
        // Hourly wage for part-time workers
        public decimal HourlyRate { get; set; }

        // Constructor
        public PartTimeEmployee(string employeeId, string name, string email, DateTime hireDate,
                                decimal hourlyRate)
            : base(employeeId, name, email, hireDate)
        {
            HourlyRate = hourlyRate;
        }

        // Different implementation of abstract method (ABSTRACTION)
        public override decimal CalculatePay(double hoursWorked)
        {
            // Part-time: simple hourly calculation
            return (decimal)hoursWorked * HourlyRate;
        }

        // Different override (POLYMORPHISM)
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Type: Part-Time");
            Console.WriteLine($"Hourly Rate: {HourlyRate:C}/hour");
        }
    }
}