//FullTimeEmployee.cs
using System;

namespace EmployeeTimeTracker.Models
{
    // Demonstrates INHERITANCE and POLYMORPHISM
    public class FullTimeEmployee : Employee
    {
        // Additional properties specific to full-time employees
        public decimal MonthlySalary { get; set; }
        public decimal OvertimeRate { get; set; }

        // Constructor calls base constructor
        public FullTimeEmployee(string employeeId, string name, string email, DateTime hireDate,
                                decimal monthlySalary, decimal overtimeRate)
            : base(employeeId, name, email, hireDate)
        {
            MonthlySalary = monthlySalary;
            OvertimeRate = overtimeRate;
        }

        // Implementation of abstract method (ABSTRACTION)
        public override decimal CalculatePay(double hoursWorked)
        {
            // Full-time: 160 hours/month base, overtime after that
            double regularHours = Math.Min(hoursWorked, 160);
            double overtimeHours = Math.Max(0, hoursWorked - 160);

            decimal regularPay = MonthlySalary;
            decimal overtimePay = (decimal)overtimeHours * OvertimeRate;

            return regularPay + overtimePay;
        }

        // Overriding virtual method (POLYMORPHISM)
        public override void DisplayInfo()
        {
            base.DisplayInfo(); // Call parent method
            Console.WriteLine($"Type: Full-Time");
            Console.WriteLine($"Monthly Salary: {MonthlySalary:C}");
            Console.WriteLine($"Overtime Rate: {OvertimeRate:C}/hour");
        }
    }
}