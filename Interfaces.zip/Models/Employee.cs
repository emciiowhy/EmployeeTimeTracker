using System;
using EmployeeTimeTracker.Utilities;

namespace EmployeeTimeTracker.Models
{
    // Base class demonstrating ENCAPSULATION and ABSTRACTION
    public abstract class Employee
    {
        // Private fields (Encapsulation)
        private string _employeeId = string.Empty;
        private string _name = string.Empty;
        private string _email = string.Empty;
        private DateTime _hireDate;

        // Properties with validation
        public string EmployeeId
        {
            get => _employeeId;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Employee ID cannot be empty.");
                _employeeId = value;
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Name cannot be empty.");
                _name = value;
            }
        }

        public string Email
        {
            get => _email;
            set
            {
                if (!Validators.IsValidEmail(value))
                    throw new ArgumentException("Invalid email format.");
                _email = value;
            }
        }

        public DateTime HireDate
        {
            get => _hireDate;
            set => _hireDate = value;
        }

        // Constructor
        protected Employee(string employeeId, string name, string email, DateTime hireDate)
        {
            EmployeeId = employeeId;
            Name = name;
            Email = email;
            HireDate = hireDate;
        }

        // Abstract method (ABSTRACTION)
        public abstract decimal CalculatePay(double hoursWorked);

        // Virtual method (POLYMORPHISM)
        public virtual void DisplayInfo()
        {
            Console.WriteLine($"ID: {EmployeeId}");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Email: {Email}");
            Console.WriteLine($"Hire Date: {HireDate.ToShortDateString()}");
        }

        // Regular method
        public string GetEmployeeType() => GetType().Name;
    }
}
